xnu-kernel.zip - Exynos 990 (Exynos 9830) XNU loader + kernel

Model : z3s (SM-G988B)
Image : xnu.img, 16984064 bytes, sha256 e5a8393b681fc033d6fefaeba87b2adb7a0c0a12f090d80ce0e8b18aea441a0b
Layout: boot header v2, loader 63648 bytes in the kernel slot,
        XNU payload in the ramdisk slot.

Flash: install this zip in TWRP, or write xnu.img to the "boot"
partition by hand:
  adb push xnu.img /tmp/xnu.img
  adb shell dd if=/tmp/xnu.img of=/dev/block/by-name/boot bs=4M conv=fsync

The zip writes the boot partition only.  It refuses to run on a
device whose ro.product.device is not z3s.
