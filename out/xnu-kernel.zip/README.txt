xnu-kernel.zip - Exynos 990 (Exynos 9830) XNU loader + kernel

Model : z3s (SM-G988B)
Image : xnu.img, 16984064 bytes, sha256 7c5a14b853d8540db1bc098ea825c5d8635bc3214f4bff1399e041c67e012f42
Layout: boot header v2, loader 63936 bytes in the kernel slot,
        XNU payload in the ramdisk slot.

Flash: install this zip in TWRP, or write xnu.img to the "boot"
partition by hand:
  adb push xnu.img /tmp/xnu.img
  adb shell dd if=/tmp/xnu.img of=/dev/block/by-name/boot bs=4M conv=fsync

The zip writes the boot partition only.  It refuses to run on a
device whose ro.product.device is not z3s.
