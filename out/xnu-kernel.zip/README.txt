xnu-kernel.zip - Exynos 990 (Exynos 9830) XNU loader + kernel

Model : z3s (SM-G988B)
Image : xnu.img, 16984064 bytes, sha256 87914244243f86e820b2af94b14213cd1e7fd023e66265d90fa14064bd5a82d8
Layout: boot header v2, loader 63968 bytes in the kernel slot,
        XNU payload in the ramdisk slot.

Flash: install this zip in TWRP, or write xnu.img to the "boot"
partition by hand:
  adb push xnu.img /tmp/xnu.img
  adb shell dd if=/tmp/xnu.img of=/dev/block/by-name/boot bs=4M conv=fsync

The zip writes the boot partition only.  It refuses to run on a
device whose ro.product.device is not z3s.
